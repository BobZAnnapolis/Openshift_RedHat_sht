<?php
$dbhost = getenv("OPENSHIFT_MYSQL_DB_HOST");
$dbuser = getenv("OPENSHIFT_MYSQL_DB_USERNAME");
$dbpassword = getenv("OPENSHIFT_MYSQL_DB_PASSWORD");
$dbname = getenv("OPENSHIFT_APP_NAME");

$logdir = getenv("OPENSHIFT_LOG_DIR");
$logfile = fopen($logdir."lampstack.log",'a');

mysql_connect($dbhost, $dbuser, $dbpassword) or die(mysql_error()); 
fwrite($logfile, date("m/d/Y h:i:s a", time())." Connected to database.\n");

mysql_select_db($dbname) or die(mysql_error()); 
$result = mysql_query("SELECT * FROM users") or die(mysql_error()); 
fwrite($logfile, date("m/d/Y h:i:s a", time())." Ran query : Select * FROM users.\n");

echo "<html>";
echo "<body bgcolor='Beige'>";

echo "<table border cellpadding=3>"; 
echo "<tr><td>Username</td>";
echo "<td>Email Address</td></tr>";

while($currentRow = mysql_fetch_array( $result )) 
{
  echo "<tr>"; 
  echo "<td>".$currentRow['username']."</td>";
  echo "<td>".$currentRow['email']."</td>";
  echo "</tr>";
} 
       
echo "</table>";

echo "<br><br>";
echo "<b>Database Name</b>:  lampstack<br>";
echo "<b>Password</b>:       WxJBUqWGtVnw<br>";
echo "<b>Username</b>:       adminvFvV9TN<br><br>";

echo "<b>phpmyadmin-4</b>:   <a href='http://lampstack-rjz.rhcloud.com/phpmyadmin/'>phpMyAdmin page</a><br>";

echo "</body>";
echo "</html>";

fwrite($logfile, date("m/d/Y h:i:s a", time())." Returned results to browser.\n\n");
fclose($logfile);

