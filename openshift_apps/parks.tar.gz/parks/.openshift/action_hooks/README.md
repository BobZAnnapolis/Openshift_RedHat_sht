For information about action hooks supported by OpenShift, consult the documentation:

http://openshift.github.io/documentation/oo_user_guide.html#the-openshift-directory
