package org.openshift.data.model;

public class ParkData {

	private String name;
	private float[] pos;
	
	public String getName() {
		return name;
	}
	public void setName(String _name) {
		name = _name;
	}
	public float[] getPos() {
		return pos;
	}
	public void setPos(float[] pos) {
		this.pos = pos;
	}
	
}
