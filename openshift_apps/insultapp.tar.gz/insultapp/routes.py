#!/usr/bin/env python
#Coding: utf-8
#Filename: routes.py
#Date Created: 09 Jan 2015
#Last Modified: 09 Jan 2015 (14:17:58)
#Summary:
#Author: Michael McConachie <dude@thelinuxgeek.us>
#License: GPLv3

import os
from flask import Flask
import insulter

app = Flask(__name__)
# keeps Flask from swallowing error msgs
app.config['PROPOGATE_EXCEPTIONS'] = True

@app.route("/")
def insult():
      return insulter.insult()

@app.route("/<name>")
def insult_name(name):
      return insulter.named_insult(name);

if __name__ == "__main__":
      app.run()

