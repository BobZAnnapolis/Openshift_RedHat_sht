from setuptools import setup

setup(name='insultapp',
      version='1.0',
      description='OpenShift App',
      author='bahbzee',
      author_email='bahbzee@gmail.com',
      url='http://www.python.org/sigs/distutils-sig/',
      install_requires=['Flask==0.10.1', 'psycopg2==2.5.2', 'sendgrid' ],
     )

