date >> $OPENSHIFT_REPO_DIR/crontest.txt

