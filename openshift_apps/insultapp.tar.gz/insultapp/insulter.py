#!/usr/bin/env python
#Coding: utf-8
#Filename: insultery.py
#Date Created: 09 Jan 2015
#Last Modified: 15 Jan 2015 (15:21:05)
#Summary:
#Author: Michael McConachie <dude@thelinuxgeek.us>
#License: GPLv3

import psycopg2
import sendgrid
import os
import logging
from random import choice

def insult():
      logging.info('insultapp:insult() called')
      str_insult = "Thou " + generate_insult() + " !!"
      sg_email(str_insult)
      return str_insult


def named_insult(name):
      str_insult = name + ", thou " + generate_insult() + " !!"
      sg_email(str_insult)
      return str_insult 



#first_adjs = ["artless", "bawdy", "beslubbering", "bootless", "churlish"]
#second_adjs = ["base-court", "bat-fowling", "beef-witted", "beetle-headed", "boil-brained"]
#nouns = ["apple-john", "baggage", "barnacle", "bladder", "boar-pig"]
#return choice(first_adjs) + " " + choice(second_adjs) + " " + choice(nouns)
def generate_insult():
  logging.info('insultapp:generate_insult() called')
  local_cursor = get_cursor()
  short_word = get_word(local_cursor, "short_adjective")
  long_word = get_word(local_cursor, "long_adjective")
  noun_word = get_word(local_cursor, "noun")
  close_cursor(local_cursor)
  logging.info('insultapp:generate_insult() : short_adj: ' + short_word)
  local_cursor = get_cursor()
  final_result = short_word + " " + long_word + " " + noun_word
  return final_result


def get_word(cursor, table):
  sql = "select string from " + table + " offset random()*(select count(*) from " + table + ") limit 1;"
  cursor.execute(sql)
  result = cursor.fetchone()
  return result[0]


def get_cursor():
  #open a connection
  conn = psycopg2.connect( database=os.environ['OPENSHIFT_APP_NAME'],
                           user=os.environ['OPENSHIFT_POSTGRESQL_DB_USERNAME'],
                           password=os.environ['OPENSHIFT_POSTGRESQL_DB_PASSWORD'],
                           host=os.environ['OPENSHIFT_POSTGRESQL_DB_HOST'],
                           port=os.environ['OPENSHIFT_POSTGRESQL_DB_PORT'] )
  #get a cursor from the connection
  cursor = conn.cursor()
  return cursor


def close_cursor(cursor):
  conn = cursor.connection
  cursor.close()
  conn.close()


def sg_email(insult):
  sg = sendgrid.SendGridClient("BobZ", "950Breakwater")
  message = sendgrid.Mail()

  message.add_to("rzawislak@capitalsalesgroup.com")
  message.set_from("bahbzee@gmail.com")
  message.set_subject("Sending with SendGrid from webapp")
  message.set_html(insult)

  sg.send(message)
